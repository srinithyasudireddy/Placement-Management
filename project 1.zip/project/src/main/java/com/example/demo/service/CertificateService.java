package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Certificate;

public interface CertificateService {

	Certificate saveCertificate(Certificate certificate);

	List<Certificate> fetchCertificateList();

	void deletecertificatetById(Long id);

	Certificate fetchCertificateById(Long id);

	Certificate updateCertificate(long certificateId, Certificate certificate);

	Certificate fetchCertificateById(String string);

	
	

}
