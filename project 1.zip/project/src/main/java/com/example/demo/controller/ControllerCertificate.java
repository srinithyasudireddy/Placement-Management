package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Certificate;
import com.example.demo.service.CertificateService;
import org.springframework.web.bind.annotation.PutMapping;


@RestController
public class ControllerCertificate {
	@Autowired
	CertificateService service;
	@PostMapping("/certificate")
	public Certificate saveCertificate(@RequestBody Certificate certificate ) {
		return service.saveCertificate(certificate);
	}
	@GetMapping("/certificate")
    public List<Certificate> fetchPlacementList() {
        //LOGGER.info("Inside fetchDepartmentList of DepartmentController");
        return service.fetchCertificateList();
    }
	
	
	 
	 @GetMapping("/certificate/{id}")
	    public Certificate fetchCertificateById(@PathVariable("id") Long id)
	            {
	        return service.fetchCertificateById("id");	            }
	 
	@DeleteMapping("/certificate/{id}")
	public String deleteCertificateById(@PathVariable("id") Long id) {
		service.deletecertificatetById(id);
		return "certificate delete Successfully!!";
	}
	@PutMapping("/certificate/{id}") 
	 public Certificate updateCertificate(@PathVariable("id") long certificateId, @RequestBody
	  Certificate certificate) { 
		  return service.updateCertificate(certificateId,certificate);
	}
}

	


