package com.example.demo.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Certificate;
import com.example.demo.repository.CertificateRepository;
@Repository
public class CertificateServiceImpl implements CertificateService {
	
	@Autowired
	private CertificateRepository repository;

	@Override
	public Certificate saveCertificate(Certificate certificate) {
		// TODO Auto-generated method stub
		return repository.save(certificate);
	}

	@Override
	public List<Certificate> fetchCertificateList() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public void deletecertificatetById(Long id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}



	

	@Override
	public Certificate updateCertificate(long certificateId, Certificate certificate) {
		// TODO Auto-generated method stub
Certificate certificate2= repository.findById(certificateId).get();
		
		if(Objects.nonNull(certificate.getYear()) &&
			       !"".equals(certificate.getYear())) {
			           certificate2.setYear(certificate.getYear());
			       }

			      
			       if(Objects.nonNull(certificate.getCollege()) &&
			               !"".equalsIgnoreCase(certificate.getCollege())) {
			           certificate2.setCollege(certificate.getCollege());
			       }

			       return repository.save(certificate2);
	}

	@Override
	public Certificate fetchCertificateById(Long id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}

	@Override
	public Certificate fetchCertificateById(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
}
	


	
	

	
	
